import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import shap
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import warnings

# ======================
# 0. 核心兼容性修复
# ======================
if not hasattr(np, 'bool'):
    np.bool = bool
warnings.filterwarnings('ignore')

# 设置全局字体
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['axes.unicode_minus'] = False

# ======================
# 1. 数据读取与预处理
# ======================
data_path = r"G:\honglaoshi\oneclass\建模后的shap_s3vm\zf_400num_origin（删除了原始的aspect全部为0的一行）.xlsx"
data = pd.read_excel(data_path)
data = data.dropna()
X = data.drop(['ls'], axis=1)
y = data['ls']

# ======================
# 2. 划分训练集和测试集
# ======================
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=2021, shuffle=True)

# ======================
# 3. 训练随机森林模型 (RF)
# ======================
rf_clf = RandomForestClassifier(n_estimators=284,
                                random_state=2021,
                                n_jobs=-1)
rf_clf.fit(X_train, y_train)
print("----- Random Forest Classifier Training Completed -----")

# ======================
# 4. SHAP 分析与维度处理
# ======================
explainer = shap.TreeExplainer(rf_clf)
shap_results = explainer.shap_values(X_test)

# 提取类别 1 (滑坡) 的 SHAP 值
if isinstance(shap_results, list):
    shap_values_to_plot = shap_results[1]
elif len(shap_results.shape) == 3:
    shap_values_to_plot = shap_results[:, :, 1]
else:
    shap_values_to_plot = shap_results

# ======================
# 5. 组图绘制 (1行2列 布局)
# ======================
# 修改为 1x2 布局，调整 figsize 适应横向排列 (宽度16, 高度6)
fig, axs = plt.subplots(1, 2, figsize=(16, 6))

# 仅定义 a 和 b 两个配置
plot_configs = [
    ('Altitude', None, '(a)', 'Altitude'),
    ('Distance to roads', None, '(b)', 'Distance to roads')
]

# 遍历绘制
for i, (feat, inter_feat, label, title) in enumerate(plot_configs):
    ax = axs[i]

    if feat in X_test.columns:
        # 绘制依赖图 (interaction_index=None 时 SHAP 会自动选择最相关的特征进行着色)
        shap.dependence_plot(feat, shap_values_to_plot, X_test,
                             interaction_index=inter_feat,
                             ax=ax,
                             show=False)

        # 美化标题与标号
        ax.set_title(f'SHAP {title}', fontsize=16, pad=15)
        # 标号位置
        ax.text(-0.15, 1.05, label, transform=ax.transAxes,
                fontsize=22, fontweight='bold', va='top')
    else:
        ax.text(0.5, 0.5, f"Feature '{feat}'\nnot found",
                ha='center', va='center', color='red')

# ======================
# 6. 保存与显示
# ======================
plt.tight_layout()
# 调整列间距
plt.subplots_adjust(wspace=0.3)

output_fig = r'G:\honglaoshi\oneclass\建模后的shap_s3vm\rf_shap_2_plots_ab.jpg'
os.makedirs(os.path.dirname(output_fig), exist_ok=True)

plt.savefig(output_fig, dpi=300, bbox_inches='tight')
plt.show()

print(f'✅ 1行2列 SHAP图已完成并保存至: {output_fig}')
