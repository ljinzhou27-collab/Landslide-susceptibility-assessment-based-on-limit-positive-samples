import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import shap
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import warnings

# ======================
# 0. 核心兼容性修复 (防止 numpy 与旧版 shap 冲突)
# ======================
if not hasattr(np, 'bool'):
    np.bool = bool
warnings.filterwarnings('ignore')

# 设置全局字体为 Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['axes.unicode_minus'] = False

# ======================
# 1. 数据读取与预处理
# ======================
data_path = r"G:\honglaoshi\oneclass\建模后的shap_s3vm\zf_400num_origin（删除了原始的aspect全部为0的一行）.xlsx"
data = pd.read_excel(data_path)
data = data.dropna()
X = data.drop(['ls'], axis=1)
y = data['ls']

# ======================
# 2. 划分训练集和测试集
# ======================
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=2021, shuffle=True)

# ======================
# 3. 训练随机森林模型 (RF)
# ======================
rf_clf = RandomForestClassifier(n_estimators=284,
                                random_state=2021,
                                n_jobs=-1)
rf_clf.fit(X_train, y_train)
print("----- Random Forest Classifier Training Completed -----")

# ======================
# 4. SHAP 分析与维度处理
# ======================
explainer = shap.TreeExplainer(rf_clf)
shap_results = explainer.shap_values(X_test)

# 提取类别 1 (滑坡) 的 SHAP 值，解决 RF 可能返回 3D 数组或列表的问题
if isinstance(shap_results, list):
    shap_values_to_plot = shap_results[1]
elif len(shap_results.shape) == 3:
    shap_values_to_plot = shap_results[:, :, 1]
else:
    shap_values_to_plot = shap_results

# ======================
# 5. 组图绘制 (3行2列 布局)
# ======================
# 创建 3行2列 的画布，调整 figsize 比例以适应纵向排版
fig, axs = plt.subplots(2, 2, figsize=(14, 20))

# 定义要绘制的配置：(主特征, 交互特征, 标号, 标题)
plot_configs = [
    ('Altitude', None, '(a)', 'Altitude'),
    #('Distance to rivers', None, '(b)', 'Distance to rivers'),
    ('Distance to roads', None, '(b)', 'Distance to roads'),
    #('NDVI', None, '(d)', 'NDVI'),
    ('Altitude', 'Distance to roads', '(e)', 'Interaction: Precip. x Alt.'),  # 交互项
    ('Distance to roads', 'Altitude', '(f)', 'Interaction: Alt. x Precip.')  # 交互项
]

# 展平坐标轴数组，方便遍历
ax_flat = axs.flatten()

for i, (feat, inter_feat, label, title) in enumerate(plot_configs):
    ax = ax_flat[i]

    # 检查特征是否存在
    if feat in X_test.columns:
        # 绘制依赖/交互图
        shap.dependence_plot(feat, shap_values_to_plot, X_test,
                             interaction_index=inter_feat,
                             ax=ax,
                             show=False)

        # 美化标题与标号
        ax.set_title(f'Dependence Plot: {title}', fontsize=14, pad=15)
        # 标号位置微调，确保不被 y 轴标题遮挡
        ax.text(-0.15, 1.05, label, transform=ax.transAxes,
                fontsize=22, fontweight='bold', va='top')
    else:
        ax.text(0.5, 0.5, f"Feature '{feat}'\nnot found",
                ha='center', va='center', color='red')

# ======================
# 6. 保存与显示
# ======================
# 使用 tight_layout 自动调整基础间距
plt.tight_layout()
# 增加垂直间距 hspace，给纵向布局留出更多呼吸空间
plt.subplots_adjust(hspace=0.35, wspace=0.25)

output_fig = r'G:\honglaoshi\oneclass\建模后的shap_s3vm\rf_shap_interaction_3x2_plots.jpg'
os.makedirs(os.path.dirname(output_fig), exist_ok=True)

plt.savefig(output_fig, dpi=300, bbox_inches='tight')
plt.show()

print(f'✅ 3行2列交互分析图已完成并保存至: {output_fig}')
