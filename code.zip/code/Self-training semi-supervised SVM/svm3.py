import os
import numpy as np
import rasterio
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
import geopandas as gpd
from shapely.geometry import Point

# --- 配置参数 ---
ls_path = r"G:\honglaoshi\oneclass\半监督尝试\ls.tif"
factors_dir = r"G:\honglaoshi\oneclass\fr\factor_fr"
max_iter = 10
top_k = 500

# 输出路径
output_combined_path = r"G:\honglaoshi\oneclass\半监督尝试\classification_result_1_2.tif"
output_prob_path = r"s3vm_initial_susceptibility.tif"
# 新增矢量点输出路径
output_neg_points_shp = r"reliable_neg_points.shp"
output_pos_points_shp = r"reliable_pos_points.shp"


# 1. 数据加载与预处理
def load_data(ls_path, factors_dir):
    with rasterio.open(ls_path) as src:
        ls_mask = src.read(1)
        profile = src.profile
        nodata = src.nodata
        crs = src.crs
        transform = src.transform

    factor_files = [os.path.join(factors_dir, f) for f in os.listdir(factors_dir) if f.endswith('.tif')]
    factor_list = []
    for f in factor_files:
        with rasterio.open(f) as src:
            factor_list.append(src.read(1))

    factors_stack = np.stack(factor_list, axis=-1)
    return ls_mask, factors_stack, profile, nodata, crs, transform


ls_mask, factors_stack, profile, nodata, crs, transform = load_data(ls_path, factors_dir)
rows, cols, dims = factors_stack.shape

X_all = factors_stack.reshape(-1, dims)
y_all_initial = ls_mask.reshape(-1)

# 掩膜处理
valid_mask = (y_all_initial != nodata) if nodata is not None else np.ones_like(y_all_initial, dtype=bool)
valid_mask = valid_mask & (~np.isnan(X_all).any(axis=1))

landslide_idx = np.where((y_all_initial == 1) & valid_mask)[0]
unlabeled_idx = np.where((y_all_initial == 0) & valid_mask)[0]

print(f"滑坡样本数: {len(landslide_idx)}, 待定样本数: {len(unlabeled_idx)}")

# (1) 准备初始训练集
np.random.shuffle(unlabeled_idx)
initial_neg_idx = unlabeled_idx[:len(landslide_idx)]
remaining_unlabeled_idx = unlabeled_idx[len(landslide_idx):]

train_idx = np.concatenate([landslide_idx, initial_neg_idx])
y_train = np.concatenate([np.ones(len(landslide_idx)), np.zeros(len(initial_neg_idx))])
X_train = X_all[train_idx]

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)

# (2)-(4) 自学习迭代
current_X_train = X_train_scaled
current_y_train = y_train
current_unlabeled_idx = remaining_unlabeled_idx

for i in range(max_iter):
    print(f"迭代轮次: {i + 1}/{max_iter}...")
    clf = SVC(kernel='rbf', probability=True, gamma='auto')
    clf.fit(current_X_train, current_y_train)

    if len(current_unlabeled_idx) == 0: break

    X_unlabeled = scaler.transform(X_all[current_unlabeled_idx])
    probs = clf.predict_proba(X_unlabeled)
    prob_non_landslide = probs[:, 0]

    sorted_indices = np.argsort(prob_non_landslide)[::-1]
    num_to_add = min(top_k, len(sorted_indices))
    added_idx_in_unlabeled = sorted_indices[:num_to_add]

    new_samples_idx = current_unlabeled_idx[added_idx_in_unlabeled]
    new_samples_X = X_all[new_samples_idx]
    new_samples_y = np.zeros(num_to_add)

    current_X_train = np.vstack([current_X_train, scaler.transform(new_samples_X)])
    current_y_train = np.concatenate([current_y_train, new_samples_y])
    current_unlabeled_idx = np.delete(current_unlabeled_idx, added_idx_in_unlabeled)

# (5) 最终预测
print("全区预测中...")
final_probs = np.full(len(X_all), -1.0, dtype=np.float32)
batch_size = 100000
for i in range(0, len(X_all), batch_size):
    batch_idx = np.arange(i, min(i + batch_size, len(X_all)))
    effective_batch = batch_idx[valid_mask[batch_idx]]
    if len(effective_batch) > 0:
        X_batch = scaler.transform(X_all[effective_batch])
        final_probs[effective_batch] = clf.predict_proba(X_batch)[:, 1]

# --- 分类逻辑 ---
combined_result = np.zeros(len(y_all_initial), dtype=np.uint8)
# 负样本 (1): 概率 <= 0.5 且原始不是滑坡
neg_mask = (final_probs >= 0) & (final_probs <= 0.5) & (y_all_initial != 1)
combined_result[neg_mask] = 1
# 正样本 (2): 概率 > 0.5
pos_mask = (final_probs > 0.5) & (final_probs <= 1.0)
combined_result[pos_mask] = 2

# --- 保存栅格结果 ---
combined_result_reshaped = combined_result.reshape(rows, cols)
combined_profile = profile.copy()
combined_profile.update(dtype=rasterio.uint8, count=1, nodata=0)
with rasterio.open(output_combined_path, 'w', **combined_profile) as dst:
    dst.write(combined_result_reshaped, 1)

prob_profile = profile.copy()
prob_profile.update(dtype=rasterio.float32, count=1, nodata=-1.0)
with rasterio.open(output_prob_path, 'w', **prob_profile) as dst:
    dst.write(final_probs.reshape(rows, cols), 1)


# --- 新增：栅格转矢量点函数 ---
def save_points_to_shp(mask_condition, ls_value, output_path, crs, transform, rows, cols):
    print(f"正在生成矢量点: {output_path} ...")
    # 获取满足条件的像元索引 (row_indices, col_indices)
    idx_rows, idx_cols = np.where(mask_condition.reshape(rows, cols))

    if len(idx_rows) == 0:
        print(f"类别 {ls_value} 无样本，跳过保存。")
        return

    # 将行列号转为地理坐标
    xs, ys = rasterio.transform.xy(transform, idx_rows, idx_cols)

    # 构建点要素和属性
    geometry = [Point(x, y) for x, y in zip(xs, ys)]
    df = gpd.GeoDataFrame({
        'ls': [ls_value] * len(geometry)
    }, geometry=geometry, crs=crs)

    # 保存为 Shapefile
    df.to_file(output_path)
    print(f"矢量点已成功保存，共 {len(geometry)} 个点。")


# 导出负样本矢量点 (ls=0)
save_points_to_shp(neg_mask, 0, output_neg_points_shp, crs, transform, rows, cols)

# 导出正样本矢量点 (ls=1)
save_points_to_shp(pos_mask, 1, output_pos_points_shp, crs, transform, rows, cols)

print(f"处理完成！")
