import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import (confusion_matrix, f1_score, roc_auc_score,
                             matthews_corrcoef, mean_squared_error, brier_score_loss)
from sklearn.preprocessing import StandardScaler
import rasterio
import os
import optuna
import warnings

warnings.filterwarnings('ignore')

# 基础配置
output_dir = r"G:\honglaoshi\oneclass\sample3"
os.makedirs(output_dir, exist_ok=True)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# ==========================================
# 一、模型结构定义 (BPNN)
# ==========================================
class BPNNClassifier(nn.Module):
    def __init__(self, input_size, num_classes, hidden_sizes=[100, 50]):
        super(BPNNClassifier, self).__init__()
        layers = []
        prev_size = input_size
        for hidden_size in hidden_sizes:
            layers.append(nn.Linear(prev_size, hidden_size))
            layers.append(nn.ReLU())
            prev_size = hidden_size
        layers.append(nn.Linear(prev_size, num_classes))
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)


# ==========================================
# 二、核心逻辑函数 (训练、预测、指标)
# ==========================================
def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    total_loss, correct, total = 0, 0, 0
    for inputs, labels in loader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * inputs.size(0)
        correct += (outputs.argmax(1) == labels).sum().item()
        total += labels.size(0)
    return total_loss / total, correct / total


def get_predictions(model, loader, device):
    model.eval()
    all_labels, all_preds, all_probs = [], [], []
    with torch.no_grad():
        for inputs, labels in loader:
            inputs = inputs.to(device)
            outputs = model(inputs)
            probs = torch.softmax(outputs, dim=1)[:, 1]
            preds = outputs.argmax(1)
            all_labels.extend(labels.numpy())
            all_preds.extend(preds.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())
    return np.array(all_labels), np.array(all_preds), np.array(all_probs)


def calculate_detailed_metrics(y_true, y_pred, y_prob):
    """严格匹配要求的评价指标格式"""
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    sensitivity = tp / (tp + fn) * 100 if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) * 100 if (tn + fp) > 0 else 0
    accuracy = (tp + tn) / (tp + tn + fp + fn) * 100

    f1_vals = f1_score(y_true, y_pred, average=None)
    f1_str = f"Class 0: {round(f1_vals[0], 4)}, Class 1: {round(f1_vals[1], 4)}"

    mcc = matthews_corrcoef(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_prob))
    brier = brier_score_loss(y_true, y_prob)
    roc_auc = roc_auc_score(y_true, y_prob)

    return {
        "True positive": tp, "True negative": tn, "False positive": fp, "False negative": fn,
        "Sensitivity (%)": round(sensitivity, 2), "Specificity (%)": round(specificity, 2),
        "Accuracy (%)": round(accuracy, 2), "F1 (per class)": f1_str,
        "Matthews Correlation Coefficient": round(mcc, 4), "RMSE": round(rmse, 4),
        "Brier score": round(brier, 4), "ROC AUC": round(roc_auc, 4)
    }


# ==========================================
# 三、Optuna 寻优目标
# ==========================================
def objective(trial, X_tr, y_tr, X_te, y_te):
    lr = trial.suggest_float("lr", 1e-4, 1e-2, log=True)
    n_layer1 = trial.suggest_int("n_layer1", 32, 256)
    n_layer2 = trial.suggest_int("n_layer2", 16, 128)
    weight_decay = trial.suggest_float("weight_decay", 1e-5, 1e-3, log=True)
    batch_size = trial.suggest_categorical("batch_size", [16, 32, 64])

    train_loader = DataLoader(TensorDataset(torch.FloatTensor(X_tr), torch.LongTensor(y_tr.values)),
                              batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(TensorDataset(torch.FloatTensor(X_te), torch.LongTensor(y_te.values)),
                             batch_size=batch_size, shuffle=False)

    model = BPNNClassifier(input_size=X_tr.shape[1], num_classes=2, hidden_sizes=[n_layer1, n_layer2]).to(device)
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    criterion = nn.CrossEntropyLoss()

    for epoch in range(30):  # 寻优训练30轮
        train_one_epoch(model, train_loader, criterion, optimizer, device)

    _, _, probs = get_predictions(model, test_loader, device)
    return roc_auc_score(y_te, probs)


# ==========================================
# 四、主程序流
# ==========================================
# 1. 数据准备
data = pd.read_excel(r"G:\honglaoshi\oneclass\sample3\zf_400num_fr.xlsx")
X = data.drop(columns=["ls"])
y = data["ls"]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42, stratify=y)

# 2. Optuna 寻优
print("🚀 启动 BPNN 贝叶斯超参数寻优...")
study = optuna.create_study(direction="maximize")
study.optimize(lambda trial: objective(trial, X_train, y_train, X_test, y_test), n_trials=20)
best_params = study.best_params
print(f"✅ 最佳参数: {best_params}")

# 3. 最终训练
print("🔥 使用最佳参数进行最终训练 (100 Epochs)...")
final_model = BPNNClassifier(X_train.shape[1], 2, [best_params['n_layer1'], best_params['n_layer2']]).to(device)
optimizer = optim.Adam(final_model.parameters(), lr=best_params['lr'], weight_decay=best_params['weight_decay'])
criterion = nn.CrossEntropyLoss()

train_loader = DataLoader(TensorDataset(torch.FloatTensor(X_train), torch.LongTensor(y_train.values)),
                          batch_size=best_params['batch_size'], shuffle=True)
for epoch in range(100):
    train_one_epoch(final_model, train_loader, criterion, optimizer, device)

# 4. 获取预测与评估结果
# 确保评估时不打乱顺序
train_eval_loader = DataLoader(TensorDataset(torch.FloatTensor(X_train), torch.LongTensor(y_train.values)),
                               batch_size=best_params['batch_size'], shuffle=False)
test_eval_loader = DataLoader(TensorDataset(torch.FloatTensor(X_test), torch.LongTensor(y_test.values)),
                              batch_size=best_params['batch_size'], shuffle=False)

y_tr_true, y_tr_pred, y_tr_prob = get_predictions(final_model, train_eval_loader, device)
y_te_true, y_te_pred, y_te_prob = get_predictions(final_model, test_eval_loader, device)

train_m = calculate_detailed_metrics(y_tr_true, y_tr_pred, y_tr_prob)
test_m = calculate_detailed_metrics(y_te_true, y_te_pred, y_te_prob)

# 5. 保存至 Excel
metrics_df = pd.DataFrame(
    {"Metric": train_m.keys(), "Training Set": train_m.values(), "Validation Set": test_m.values()})
train_df = pd.DataFrame({"True_Label": y_tr_true, "Predicted_Class": y_tr_pred, "Probability": y_tr_prob})
test_df = pd.DataFrame({"True_Label": y_te_true, "Predicted_Class": y_te_pred, "Probability": y_te_prob})
params_df = pd.DataFrame([best_params])

excel_file = os.path.join(output_dir, "BPNN_Optuna_Detailed_Evaluation.xlsx")
with pd.ExcelWriter(excel_file) as writer:
    metrics_df.to_excel(writer, sheet_name="Detailed Metrics", index=False)
    train_df.to_excel(writer, sheet_name="Training Predictions", index=False)
    test_df.to_excel(writer, sheet_name="Validation Predictions", index=False)
    params_df.to_excel(writer, sheet_name="Best Hyperparameters", index=False)

print(f"📊 评估结果已保存: {excel_file}")

# ==========================================
# 五、全区域预测制图
# ==========================================
print("🌍 执行全区域预测制图...")
full_data = pd.read_csv(r'G:\honglaoshi\oneclass\sample2\factor_fr_merge1.csv')
full_scaled = scaler.transform(full_data)

final_model.eval()
all_probs = []
chunk_size = 100000
with torch.no_grad():
    for i in range(0, len(full_scaled), chunk_size):
        chunk = torch.FloatTensor(full_scaled[i:i + chunk_size]).to(device)
        outputs = final_model(chunk)
        probs = torch.softmax(outputs, dim=1)[:, 1]
        all_probs.append(probs.cpu().numpy())
final_probs = np.concatenate(all_probs)

# 保存 TIFF
raster_path = r"G:\honglaoshi\oneclass\fr\factor_fr\weighted_reclass_dem_fill.tif"
with rasterio.open(raster_path) as src:
    profile = src.profile
    raster_res = final_probs.reshape((src.height, src.width)).astype(np.float32)

profile.update(dtype=rasterio.float32, count=1)
output_tif = os.path.join(output_dir, "BPNN_Optuna_Map.tif")
with rasterio.open(output_tif, 'w', **profile) as dst:
    dst.write(raster_res, 1)

print(f"✨ 任务圆满完成！栅格图已保存至: {output_tif}")
