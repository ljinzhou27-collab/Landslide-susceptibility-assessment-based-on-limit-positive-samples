import pandas as pd
import numpy as np
import os
import warnings
import rasterio
import optuna
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (confusion_matrix, f1_score, roc_auc_score,
                             matthews_corrcoef, mean_squared_error, brier_score_loss)
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings('ignore')

# ==================== 环境与路径设置 ====================
output_dir = r"G:\honglaoshi\oneclass\sample3"
os.makedirs(output_dir, exist_ok=True)


# ==================== 1. 核心逻辑函数 ====================

def calculate_detailed_metrics(y_true, y_pred, y_prob):
    """严格匹配要求的评价指标格式"""
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()

    sensitivity = tp / (tp + fn) * 100 if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) * 100 if (tn + fp) > 0 else 0
    accuracy = (tp + tn) / (tp + tn + fp + fn) * 100

    f1_vals = f1_score(y_true, y_pred, average=None)
    f1_str = f"Class 0: {round(f1_vals[0], 4)}, Class 1: {round(f1_vals[1], 4)}"

    mcc = matthews_corrcoef(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_prob))
    brier = brier_score_loss(y_true, y_prob)
    roc_auc = roc_auc_score(y_true, y_prob)

    return {
        "True positive": tp, "True negative": tn, "False positive": fp, "False negative": fn,
        "Sensitivity (%)": round(sensitivity, 2), "Specificity (%)": round(specificity, 2),
        "Accuracy (%)": round(accuracy, 2), "F1 (per class)": f1_str,
        "Matthews Correlation Coefficient": round(mcc, 4), "RMSE": round(rmse, 4),
        "Brier score": round(brier, 4), "ROC AUC": round(roc_auc, 4)
    }


# ==================== 2. 数据准备 ====================

data = pd.read_excel(r"G:\honglaoshi\oneclass\sample3\zf_400num_fr.xlsx")
X = data.drop(columns=["ls"])
y = data["ls"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42, stratify=y)


# ==================== 3. 贝叶斯参数优化 (Optuna) ====================

def objective(trial):
    # 定义 RF 待优化的参数搜索空间
    n_estimators = trial.suggest_int("n_estimators", 50, 500)
    max_depth = trial.suggest_int("max_depth", 5, 30)
    min_samples_split = trial.suggest_int("min_samples_split", 2, 20)
    min_samples_leaf = trial.suggest_int("min_samples_leaf", 1, 10)
    max_features = trial.suggest_categorical("max_features", ["sqrt", "log2", None])

    # 构建并训练模型
    rf = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_split=min_samples_split,
        min_samples_leaf=min_samples_leaf,
        max_features=max_features,
        random_state=42,
        n_jobs=-1  # 使用所有 CPU 核心
    )

    rf.fit(X_train, y_train)

    # 评估指标为测试集的 ROC AUC
    y_prob = rf.predict_proba(X_test)[:, 1]
    return roc_auc_score(y_test, y_prob)


print("🚀 启动随机森林 (RF) 贝叶斯超参数寻优...")
study = optuna.create_study(direction="maximize")
study.optimize(objective, n_trials=20)

best_params = study.best_params
print(f"✅ 最佳参数: {best_params}")

# ==================== 4. 使用最优参数进行最终训练 ====================

print("\n🔥 使用最佳参数进行最终完整训练...")
final_rf = RandomForestClassifier(
    **best_params,
    random_state=42,
    n_jobs=-1
)
final_rf.fit(X_train, y_train)

# ==================== 5. 评价与导出 ====================

# 获取预测结果
y_tr_pred = final_rf.predict(X_train)
y_tr_prob = final_rf.predict_proba(X_train)[:, 1]

y_te_pred = final_rf.predict(X_test)
y_te_prob = final_rf.predict_proba(X_test)[:, 1]

# 计算详细指标
train_m = calculate_detailed_metrics(y_train, y_tr_pred, y_tr_prob)
test_m = calculate_detailed_metrics(y_test, y_te_pred, y_te_prob)

# 构造 DataFrame
metrics_df = pd.DataFrame(
    {"Metric": train_m.keys(), "Training Set": train_m.values(), "Validation Set": test_m.values()})
train_df = pd.DataFrame({"True_Label": y_train, "Predicted_Class": y_tr_pred, "Probability": y_tr_prob})
test_df = pd.DataFrame({"True_Label": y_test, "Predicted_Class": y_te_pred, "Probability": y_te_prob})
params_df = pd.DataFrame([best_params])

# 保存至 Excel
excel_file = os.path.join(output_dir, "RF_Optuna_Detailed_Evaluation.xlsx")
with pd.ExcelWriter(excel_file) as writer:
    metrics_df.to_excel(writer, sheet_name="Detailed Metrics", index=False)
    train_df.to_excel(writer, sheet_name="Training Predictions", index=False)
    test_df.to_excel(writer, sheet_name="Validation Predictions", index=False)
    params_df.to_excel(writer, sheet_name="Best Hyperparameters", index=False)

print(f"📊 评估结果已导出: {excel_file}")

# ==================== 6. 全区易发性制图 ====================

print("\n🌍 执行全区域预测制图...")
full_data = pd.read_csv(r'G:\honglaoshi\oneclass\sample2\factor_fr_merge1.csv')
full_scaled = scaler.transform(full_data)

# 分块预测防止内存溢出
all_probs = []
chunk_size = 100000
for i in range(0, len(full_scaled), chunk_size):
    chunk = full_scaled[i:i + chunk_size]
    probs = final_rf.predict_proba(chunk)[:, 1]
    all_probs.append(probs)
final_probs = np.concatenate(all_probs)

# 保存 TIFF
raster_path = r"G:\honglaoshi\oneclass\fr\factor_fr\weighted_reclass_dem_fill.tif"
with rasterio.open(raster_path) as src:
    profile = src.profile
    raster_res = final_probs.reshape((src.height, src.width)).astype(np.float32)

profile.update(dtype=rasterio.float32, count=1)
output_tif = os.path.join(output_dir, "RF_Optuna_Map.tif")
with rasterio.open(output_tif, 'w', **profile) as dst:
    dst.write(raster_res, 1)

print(f"✨ 任务圆满完成！栅格图已保存至: {output_tif}")
