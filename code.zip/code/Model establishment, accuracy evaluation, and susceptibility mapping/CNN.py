import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import (confusion_matrix, f1_score, roc_auc_score,
                             matthews_corrcoef, mean_squared_error, brier_score_loss)
from sklearn.preprocessing import StandardScaler
import rasterio
import os
import optuna  # 必须先安装: pip install optuna
import warnings

warnings.filterwarnings('ignore')

# 基础配置
output_dir = r"G:\honglaoshi\oneclass\sample3"
os.makedirs(output_dir, exist_ok=True)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# ==========================================
# 一、模型结构定义
# ==========================================
class CNNClassifier(nn.Module):
    def __init__(self, input_size, num_classes, num_filters=32):
        super().__init__()
        self.conv1 = nn.Conv1d(1, num_filters, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(num_filters, num_filters * 2, kernel_size=3, padding=1)
        self.pool = nn.MaxPool1d(2)
        # 经过两次池化，长度变为 input_size // 4
        self.flattened_size = (num_filters * 2) * (input_size // 4)
        self.fc1 = nn.Linear(self.flattened_size, 128)
        self.fc2 = nn.Linear(128, num_classes)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = self.pool(self.relu(self.conv2(x)))
        x = x.view(-1, self.flattened_size)
        x = self.relu(self.fc1(x))
        return self.fc2(x)


# ==========================================
# 二、核心逻辑函数
# ==========================================
def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    total_loss, correct, total = 0, 0, 0
    for inputs, labels in loader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * inputs.size(0)
        correct += (outputs.argmax(1) == labels).sum().item()
        total += labels.size(0)
    return total_loss / total, correct / total


def get_predictions(model, loader, device):
    model.eval()
    all_labels, all_preds, all_probs = [], [], []
    with torch.no_grad():
        for inputs, labels in loader:
            inputs = inputs.to(device)
            outputs = model(inputs)
            probs = torch.softmax(outputs, dim=1)[:, 1]
            preds = outputs.argmax(1)
            all_labels.extend(labels.numpy())
            all_preds.extend(preds.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())
    return np.array(all_labels), np.array(all_preds), np.array(all_probs)


def calculate_detailed_metrics(y_true, y_pred, y_prob):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    sensitivity = tp / (tp + fn) * 100 if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) * 100 if (tn + fp) > 0 else 0
    accuracy = (tp + tn) / (tp + tn + fp + fn) * 100
    f1_vals = f1_score(y_true, y_pred, average=None)
    f1_str = f"Class 0: {round(f1_vals[0], 4)}, Class 1: {round(f1_vals[1], 4)}"
    mcc = matthews_corrcoef(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_prob))
    brier = brier_score_loss(y_true, y_prob)
    roc_auc = roc_auc_score(y_true, y_prob)

    return {
        "True positive": tp, "True negative": tn, "False positive": fp, "False negative": fn,
        "Sensitivity (%)": round(sensitivity, 2), "Specificity (%)": round(specificity, 2),
        "Accuracy (%)": round(accuracy, 2), "F1 (per class)": f1_str,
        "Matthews Correlation Coefficient": round(mcc, 4), "RMSE": round(rmse, 4),
        "Brier score": round(brier, 4), "ROC AUC": round(roc_auc, 4),
    }


# ==========================================
# 三、Optuna 寻优目标函数
# ==========================================
def objective(trial, train_loader, test_loader, input_size):
    # 定义寻优参数范围
    num_filters = trial.suggest_categorical("num_filters", [16, 32, 64])
    lr = trial.suggest_float("lr", 1e-4, 1e-2, log=True)
    weight_decay = trial.suggest_float("weight_decay", 1e-5, 1e-2, log=True)

    model = CNNClassifier(input_size, 2, num_filters).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    # 寻优阶段训练 50 个 Epoch
    for epoch in range(50):
        train_one_epoch(model, train_loader, criterion, optimizer, device)

    _, _, y_prob = get_predictions(model, test_loader, device)
    # 以验证集 ROC AUC 为寻优目标
    return roc_auc_score(y_test, y_prob)


# ==========================================
# 四、主流程：数据 -> 优化 -> 最终训练
# ==========================================
# 1. 数据加载与预处理
data = pd.read_excel(r"G:\honglaoshi\oneclass\sample3\zf_400num_fr.xlsx")
X = data.drop(columns=["ls"])
y = data["ls"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
input_size = X_scaled.shape[1]
X_reshaped = X_scaled.reshape(-1, 1, input_size)

X_train, X_test, y_train, y_test = train_test_split(X_reshaped, y, test_size=0.3, random_state=42, stratify=y)

train_loader = DataLoader(TensorDataset(torch.FloatTensor(X_train), torch.LongTensor(y_train.values)), batch_size=32,
                          shuffle=True)
test_loader = DataLoader(TensorDataset(torch.FloatTensor(X_test), torch.LongTensor(y_test.values)), batch_size=32,
                         shuffle=False)

# 2. 贝叶斯优化
print("🚀 启动 Optuna 贝叶斯超参数寻优 (20 Trials)...")
study = optuna.create_study(direction="maximize")
study.optimize(lambda trial: objective(trial, train_loader, test_loader, input_size), n_trials=20)

best_params = study.best_params
print(f"✅ 寻优完成，最佳参数: {best_params}")

# 3. 使用最佳参数进行最终模型训练
print("🔥 使用最佳参数进行最终完整训练 (200 Epochs)...")
final_model = CNNClassifier(input_size, 2, best_params['num_filters']).to(device)
optimizer = optim.Adam(final_model.parameters(), lr=best_params['lr'], weight_decay=best_params['weight_decay'])
criterion = nn.CrossEntropyLoss()

for epoch in range(200):
    train_one_epoch(final_model, train_loader, criterion, optimizer, device)

# ==========================================
# 五、结果保存
# ==========================================
# 获取详细预测
train_eval_loader = DataLoader(TensorDataset(torch.FloatTensor(X_train), torch.LongTensor(y_train.values)),
                               batch_size=32, shuffle=False)
y_tr_true, y_tr_pred, y_tr_prob = get_predictions(final_model, train_eval_loader, device)
y_te_true, y_te_pred, y_te_prob = get_predictions(final_model, test_loader, device)

# 计算指标
train_m = calculate_detailed_metrics(y_tr_true, y_tr_pred, y_tr_prob)
test_m = calculate_detailed_metrics(y_te_true, y_te_pred, y_te_prob)

# 整理数据
metrics_df = pd.DataFrame(
    {"Metric": train_m.keys(), "Training Set": train_m.values(), "Validation Set": test_m.values()})
train_df = pd.DataFrame({"True_Label": y_tr_true, "Predicted_Class": y_tr_pred, "Probability": y_tr_prob})
test_df = pd.DataFrame({"True_Label": y_te_true, "Predicted_Class": y_te_pred, "Probability": y_te_prob})
params_df = pd.DataFrame([best_params])  # 保存超参数

# 导出 Excel
excel_file = os.path.join(output_dir, "CNN_Optuna_Final_Evaluation.xlsx")
with pd.ExcelWriter(excel_file) as writer:
    metrics_df.to_excel(writer, sheet_name="Detailed Metrics", index=False)
    train_df.to_excel(writer, sheet_name="Training Predictions", index=False)
    test_df.to_excel(writer, sheet_name="Validation Predictions", index=False)
    params_df.to_excel(writer, sheet_name="Best Hyperparameters", index=False)

print(f"📊 Excel 文件已生成: {excel_file}")

# ==========================================
# 六、全区域预测与制图
# ==========================================
print("🌍 执行全区域预测制图...")
full_data = pd.read_csv(r'G:\honglaoshi\oneclass\sample2\factor_fr_merge1.csv')
full_scaled = scaler.transform(full_data).reshape(-1, 1, input_size)
full_tensor = torch.FloatTensor(full_scaled).to(device)

final_model.eval()
all_probs = []
with torch.no_grad():
    for i in range(0, len(full_tensor), 5000):
        batch = full_tensor[i: i + 5000]
        all_probs.extend(torch.softmax(final_model(batch), dim=1)[:, 1].cpu().numpy())

# 保存 TIFF
raster_path = r"G:\honglaoshi\oneclass\fr\factor_fr\weighted_reclass_dem_fill.tif"
with rasterio.open(raster_path) as src:
    profile = src.profile
    raster_res = np.array(all_probs).reshape(src.height, src.width)

profile.update(dtype=rasterio.float32, count=1)
output_tiff = os.path.join(output_dir, "CNN_Optuna_map.tif")
with rasterio.open(output_tiff, 'w', **profile) as dst:
    dst.write(raster_res.astype(np.float32), 1)

print(f"✨ 任务圆满完成！栅格图: {output_tiff}")
